package controllers;

import beans.Course;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "addCourse", urlPatterns = {"/addCourse"})
public class addCourse extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {

        String iid = request.getParameter("iid");
        String title = request.getParameter("title");
        String field = request.getParameter("field");
        String dis = request.getParameter("dis");

        if (iid.isEmpty() || title.isEmpty() || field.isEmpty()) {
            throw new ServletException("Instructor ID, Course Title and Course field can not be empty");
        }

        try {
            Course course = new Course(Integer.parseInt(iid), title, field, dis);

            course.insertIntoDatabase();

            request.getSession().setAttribute("course", course);
            RequestDispatcher rd = request.getRequestDispatcher("showCourse.jsp");
            rd.forward(request, response);
        } catch (NumberFormatException e) {
            throw new ServletException("Error in Instructor ID");
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            throw new ServletException(ex);
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
}
