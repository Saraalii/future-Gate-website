package beans;

import java.sql.*;

public class Course {

    private int id;
    private String name;
    private String field;
    private String description;
    private Instructor instructor;

    public Course() {

    }

    public Course(int iid, String title, String field1, String dis) throws Exception {
        this(0, iid, title, field1, dis);
    }

    public Course(int id, int iid, String title, String field1, String dis) throws Exception {
        this.id = id;
        this.name = title;
        this.field = field1;
        this.description = dis;
        this.instructor = new Instructor(iid);
    }

    public void insertIntoDatabase() throws Exception {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
        }//end try
        catch (ClassNotFoundException e) {
            System.out.println("Error: MySQL driver not fount..");
            System.out.println(e.getMessage());
            throw new Exception("Error: MySQL driver not fount.");
        }//end catch
        try {
            //To get th port: check the setting of XAMPP or MAMP
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/futuregate", "root", "");

            String sql = "INSERT INTO course (instructor_id, name, field, description, book_cover) values (?, ?, ?, ?, ?);";

            PreparedStatement statement = con.prepareStatement(sql);

            statement.setInt(1, instructor.getId());
            statement.setString(2, name);
            statement.setString(3, field);
            statement.setString(4, description);
            statement.setString(5, "");
            
            int rows = statement.executeUpdate();
            
            if (rows == 0) {
                throw new Exception("Creating course failed.");
            }
        }//end try
        catch (SQLException e) {
            System.out.println("Error: Could not connect to mySQL server");
            System.out.println(e.getMessage());
            throw new SQLException("Error: Could not connect to mySQL server #" + e.getMessage());
        }
        
        con.close();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    public Instructor getInstructor() {
        return instructor;
    }

    public void setInstructor(Instructor instructor) {
        this.instructor = instructor;
    }

}
