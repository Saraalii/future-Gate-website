package beans;

import java.sql.*;

public class Instructor {

    private int id;
    private String name;
    private String email;
    private String speciality;

    public Instructor() {

    }

    public Instructor(int id) throws Exception {
        Connection con = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
        }//end try
        catch (ClassNotFoundException e) {
            System.out.println("Error: MySQL driver not fount..");
            System.out.println(e.getMessage());
            throw new Exception("Error: MySQL driver not fount.");
        }//end catch
        try {
            //To get th port: check the setting of XAMPP or MAMP
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/futuregate", "root", "");

            statement = con.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM instructor WHERE id =" + id);

            if (resultSet.next()) {
                this.id = id;
                this.name = resultSet.getString("name");
                this.email = resultSet.getString("email");
                this.speciality = resultSet.getString("speciality");
            } else {
                throw new Exception("Instructor not found.");
            }
            statement.close();
        }//end try
        catch (SQLException e) {
            System.out.println("Error: Could not connect to mySQL server");
            System.out.println(e.getMessage());
            throw new SQLException("Error: Could not connect to mySQL server");
        }
        con.close();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

}
