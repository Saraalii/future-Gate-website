function GEEKFORGEEKS()                                    
{ 
    var name = document.forms["ourForm"]["uname"];               
    var email = document.forms["ourForm"]["psw"];    
    var password = document.forms["ourForm"]["emailaddress"];  
   
    if (name.value == "")                                  
    { 
        window.alert("Please enter your name."); 
        name.focus(); 
        return false; 
    } 
   
    
       
    if (email.value == "")                                   
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
   
    
    if (password.value == "" )                        
    { 
        window.alert("Please enter your password"); 
        password.focus(); 
        return false; 
    }
   
    return true; 
}